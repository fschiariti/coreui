// Angular
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ColorsComponent } from './colors.component';
import { TypographyComponent } from './typography.component';
import { ClienteComponent } from './cliente.component';
import { TableBasicExampleComponent } from './table-basic-example.component';

// Theme Routing
import { ThemeRoutingModule } from './theme-routing.module';
import { DemoMaterialModule} from '../../material-module';


@NgModule({
  imports: [
    CommonModule,
    ThemeRoutingModule,
    DemoMaterialModule
  ],
  declarations: [
    ClienteComponent,
    ColorsComponent,
    TypographyComponent,
    TableBasicExampleComponent
  ]
})
export class ThemeModule { }
