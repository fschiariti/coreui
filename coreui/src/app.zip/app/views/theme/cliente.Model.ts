export class ClienteModel
{
    public id_cli: string = "";
    public cod_cli: string = "";
    public nombre: string = "";
}