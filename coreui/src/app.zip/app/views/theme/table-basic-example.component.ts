import { Component, OnInit, Inject, ViewChild} from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { getStyle, rgbToHex } from '@coreui/coreui/dist/js/coreui-utilities';
import { MatPaginator, MatTableDataSource} from '@angular/material';
import { ClienteModel } from './cliente.Model';
import { ClienteService } from './cliente.service';


export interface PeriodicElement {
  id_cli: string;
  cod_cli: string;
  nombre: string
}

/**
 * @title Basic use of `<table mat-table>`
 */
@Component({
  selector: 'table-basic-example',
  styleUrls: ['table-basic-example.css'],
  templateUrl: 'table-basic-example.html'
})

export class TableBasicExampleComponent  implements OnInit {

  private _clienteService;
  ClienteList: ClienteModel = new ClienteModel();
  output: any;
  errorMessage: any;
  list = [  {id_cli: '1', cod_cli: 'Hydrogen1', nombre:  'a'}];

  constructor(@Inject(DOCUMENT) private _document: any, clienteService: ClienteService) {
    this._clienteService = clienteService;

  }
  displayedColumns: string[] = ['id_cli', 'cod_cli', 'nombre'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  
  ngOnInit(): void {
    this.dataSource.paginator = this.paginator; 
    this._clienteService.GetAll().subscribe(
        allcliente => {
            this.list = allcliente
            this.dataSource = new MatTableDataSource<PeriodicElement>(this.list);
          },
        error => this.errorMessage = <any>error
    );
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  dataSource = new MatTableDataSource<PeriodicElement>(this.list);

}


const ELEMENT_DATA: PeriodicElement[] = [
  {id_cli: '1', cod_cli: 'Hydrogen1', nombre:  'a'},
  {id_cli: '2', cod_cli: 'Hydrogen1', nombre:  'a'},
  {id_cli: '3', cod_cli: 'Hydrogen1', nombre:  'a'},
  {id_cli: '4', cod_cli: 'Hydrogen1', nombre:  'a'},
  {id_cli: '5', cod_cli: 'Hydrogen1', nombre:  'a'}
];
