import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ClienteModel } from './cliente.Model';
import { ClienteService } from './cliente.service';


@Component({
  templateUrl: 'cliente.component.html'
})


export class ClienteComponent implements OnInit
{
  private _clienteService;
  ClienteList: ClienteModel = new ClienteModel();
  output: any;
  errorMessage: any;
  displayedColumns: string[] = ['RoleId', 'RoleName', 'Status', 'EditAction', 'DeleteAction'];
  dataSource: any;

  constructor(private _Route: Router, clienteService: ClienteService) {
      this._clienteService = clienteService;
  }

    ngOnInit(): void {
      this._clienteService.GetAll().subscribe(
          allcliente => {
              this.ClienteList = allcliente
          },
          error => this.errorMessage = <any>error
      );
  }


}